<?php
//VersionInfo:Version[3.0.1]

$_isAdmin = true;
$_adminFunction = "reports";

// initialize the program, read the config(s) and set include paths
include_once("../../include/initialize.inc");
$init = new Initialize(true);

$login = $_Registry->LoadClass("admin_login");
$login->CheckLogin();

$_Form = $_Registry->LoadClass("form");
include_once("include/orders.inc");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>Invoice</title>
<link rel="stylesheet" type="text/css" media="screen" href="../stylesheets/invoice.css">
<link rel="stylesheet" type="text/css" media="printer" href="../stylesheets/invoice.print.css">
<style>
th{
	background-color: #E5E5E5;
	color: #000000;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
.topAlign{
	vertical-align:top;
}
</style>
</head>
<body>
<div align="center" style="margin-top:10px;">
<?php getDetailRecords();?>

<?php
	$color = array();
	$color[~0] = "#e2eDe2";
	$color[0] = "#FFFFFF";
	$ck = 0;
	$payMethod = null;
	if(!empty($order[0]['payment_method'])){
		@list($payMethod,$ext) = explode('.',$order[0]['payment_method']);
	}
?>

<?php if(count($order) > 0):?>






	<table border="0" cellpadding="3" cellspacing="0" width="80%">
		<tr>
			<td align="left">
				<h1>INVOICE</h1>
			</td>
			<td align="right">
				<table border="0" cellspacing="0" cellpadding="3">
					<tr>
						<td align="right"><b>Order Number:</b> </td>
						<td><?=$order[0]['order_number'];?></td>
					</tr>
					<tr>
						<td align="right"><b>Order Date:</b> </td>
						<td><?=$order[0]['order_date'];?></td>
					</tr>
				</table>
			</td>
		</tr>
		<tr valign="top">
			<td width=50%>
			<table width="100%" border="0" cellspacing="0" cellpadding="3">
				<tr>
				<th align="left" class="invoiceHeader">BILL TO:</th>
				</tr>
				<tr>
				<td height="100" valign=top align="left">
					<?php if(!empty($billInfo['billaddress_companyname'])):?>
						<?=$billInfo['billaddress_companyname'];?><br />
					<?php endif;?>
					<?=$billInfo['billaddress_firstname'];?> <?=$billInfo['billaddress_lastname'];?><br />
					<?=$billInfo['billaddress_addr1'];?><br />
					<?php if(!empty($billInfo['billaddress_addr2'])):?>
						<?=$billInfo['billaddress_addr2'];?><br />
					<?php endif;?>
					<?=$billInfo['billaddress_city'];?>,
						<?=$billInfo['billaddress_state'];?>,
						<?=$billInfo['billaddress_postalcode'];?>
						<?=$billInfo['billaddress_country'];?><br />
					(<?=$billInfo['billaddress_areacode'];?>) <?=$billInfo['billaddress_phone'];?><br />
    		  		<?=$billInfo['billaddress_email'];?><br /><br />
    		  		<b>Payment Method:</b> &nbsp; <?=$payMethod;?><br />
				</td>
				</tr>
			</table>
			</td>
			<td width=50%>
			<table width="100%" border="0" cellspacing="0" cellpadding="3">
				<tr>
				<th align="left" class="invoiceHeader">SHIP TO:</th>
				</tr>
				<tr>
				<td height="100" valign=top align="left">
					<?php if(!empty($shipInfo['shipaddress_companyname'])):?>
						<?=$shipInfo['shipaddress_companyname'];?><br />
					<?php endif;?>
					<?=$shipInfo['shipaddress_firstname'];?> <?=$shipInfo['shipaddress_lastname'];?><br />
    		  		<?=$shipInfo['shipaddress_addr1'];?><br />
					<?php if(!empty($billInfo['shipaddress_addr2'])):?>
						<?=$billInfo['shipaddress_addr2'];?><br />
					<?php endif;?>
    		  		
    		  		
    		  		<?=$shipInfo['shipaddress_city'];?>,
    		  			<?=$shipInfo['shipaddress_state'];?>,
    		  			<?=$shipInfo['shipaddress_postalcode'];?>
    		  			<?=$shipInfo['shipaddress_country'];?><br /><br />
    		  			
					<b>Ship Via:</b> &nbsp; <?=$order[0]['shipping_method'];?><br />
					<b>Ship Date:</b> &nbsp; <?=$order[0]['date_shipped'];?><br />
					<b>Tracking Number:</b> &nbsp; <?=$order[0]['tracking_number'];?>
				</td>
				</tr>
			</table>
			</td>
		</tr>
		<tr>
			<td colspan="2">


				<table border="0" cellpadding="3" cellspacing="0" width="100%">

					<tr>
						<th class="cartHeader" width="50">SKU</th>
						<th class="cartHeader" width="90%" align="left">Description</th>
						<th class="cartHeader" width="50" align="center">Qty</th>
						<th class="cartHeader" width="75" align="center" nowrap>Price</th>
						<th class="cartHeaderEnd" width="75" align="right" nowrap>Total</th>
					</tr>
					
					<?php foreach($orderDetails as $index=>$data):?>
						<?php 
							$id = $data['ordid'];
							foreach($data as $key=>$value){
								// loads the default values from the table for enum fields
								$data[$key] = $_DB->getDefaultValues($key,$value,true);
							}
						?>

						<tr>
							<td class="cartRow" align="left"><?=$data['sku'];?></td>
							<td class="cartRow" align="left">
								<?=$data['name'];?>
								<!-- Options -->
								<?php if(!empty($data['options'])):?>
									<br />
									<?php foreach($data['options'] as $j=>$option):?>
										<div style="margin-top:2px;margin-left:10px;">
											<?php if($option['name'] != "" && $option['name'] == "Option"):?>
												<?=$option['name'];?> <?=$j+1;?>:
											<?php elseif($option['name'] != "" && $option['name'] != "Option"):?>
												<?=$option['name'];?>:
											<?php endif;?>
											<?=$option['value'];?>
											<?php if($option['price'] != "0"):?>
												<?php if($option['type'] == "option"):?>
													(<?=$option['price'];?> each)
												<?php elseif($option['type'] == "setup"):?>
													(Setup Charge: <?=$option['price'];?>)
												<?php else:?>
													(<?=$option['price'];?>)
												<?php endif;?>
											<?php endif;?>
										</div>
									<?php endforeach;?>
								<?php endif;?>
							</td>
							<td class="cartRow"><?=$data['quantity'];?></td>
							<td class="cartRow" align="right"><?=$data['price'];?></td>
							<td class="cartRowEnd" align="right">
								<?=$_Common->format_price($data['price'] * $data['quantity']);?>
							</td>
						</tr>

					<?php endforeach;?>

						<tr><td colspan="5" style="line-height:5px;">&nbsp;</td></tr>

						<!-- totals -->
						<?php if(count($totals) > 0):?>
							<?php foreach($totals[0] as $tFld=>$total):?>
								<?php
									if(preg_match("|\((.*)\)|",$tFld)){
										$matches = array();
										$fldStr = preg_match("|\((.*)\)|",$tFld,$matches);
										$fldName = ucwords($matches[1]);
									}
									else{
										$fldName = ucwords($tFld);
									}
									$total = $_Common->format_price($total,true);
								?>
								<tr>
									<td colspan="4" align="right" width="90%"><b><?=$fldName;?>:</b></td>
									<td align="right"><b><?=$total;?></b></td>
								</tr>
							<?php endforeach;?>
						<?php endif;?>
				</table>
			</td>
		</tr>
	</table>
	<form><input type=button value="Print" onClick="javascript:window.print()"></form>
<?php else:?>

	<p><b>No order to display...</b></p>
	
<?php endif;?>
</div>
</body>
</html>