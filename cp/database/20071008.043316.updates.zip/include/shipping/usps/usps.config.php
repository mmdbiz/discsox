;<?php if(!defined('INIT.CART')){die( "<html><head><title>403 Forbidden</title></head><body><h2>403 Forbidden</h2><p>You don't have permission to access this resource.<p></body></html>" );}?>
	; do not remove line above. It's used so no one can read this file from the web.
    ;
    ; USPS (XML) configuration File:
    ;
[settings]
    ;
    ; User account information
    ;
usps_user_id=
    ;
usps_password=
    ;
    ; Default ship From zip code
    ;
usps_origin_postal_code=13905
    ;
    ; Default Package Container Type: (For someone using their own package, use NONE)
    ;
default_usps_container=NONE
    ;
    ; Default Package Size: REGULAR, LARGE or OVERSIZE
    ;
default_package_size=REGULAR
    ;
    ; Machinable: TRUE or FALSE
    ;
default_machinable="True"
    ;
    ; A handling charge to add to the results
    ;
handling_charge=0.00
    ;
    ; Selected Services to display: (This is a simple, comma delimited list):
    ; Priority,Express,Parcel,First Class
    ;
usps_services=Priority,Express,Parcel
    ;
    ; The default service that is selected when the
    ; result page is displayed for domestic shipments.
    ;
default_usps_service=Priority Mail
    ;
    ; The default service that is select when the
    ; result page is displayed for International Shipments.
    ;
default_international_usps_service=Priority Mail International
    ;
    ; Should we add insurance to the rates?
    ;
add_insurance=false
	;

[services to display]
	;
	; (set the ones you want displayed to: true)
	;
	; Domestic services:
	;
Express Mail PO to PO=false
Express Mail=true
Express Mail Flat-Rate Envelope=false
Priority Mail=true
Priority Mail Flat-Rate Envelope=false
Priority Mail Flat-Rate Box=false
Parcel Post=true
Media Mail=false
Library Mail=false
	;
	; International services:
	;
First-Class Mail International=false
	;
Priority Mail International=true
Priority Mail International Flat Rate Box=false
	;
Express Mail International (EMS)=true
Express Mail International (EMS) Flat Rate Envelope=false
	;
Global Express Guaranteed=true
Global Express Guaranteed Non-Document Rectangular=false
Global Express Guaranteed Non-Document Non-Rectangular=false
	;


[insurance rates]
    ;
    ; for subtotals over $600 the insurance fee will be:
    ; $7.20 + $1.00 for every $100 or fraction of $100 above $600.
    ; counter=low range,high range,insurance fee
    ;
01=0.01,50,1.30
02=50.01,100,2.20
03=100.01,200,3.20
04=200.01,300,4.20
05=300.01,400,5.20
06=400.01,500,6.20
07=500.01,600,7.20
08=600.01,5000,7.20
    ;


[valid_containers]
	;
;Package Name             Description 
	;
	;
;Express Mail 
0-1093 Express Mail=Box, 12.25 x 15.5 x 
0-1094 Express Mail=Tube, 36 x 6 
EP13A Express Mail=Cardboard Envelope, 12.5 x 9.5 
EP13C Express Mail=Tyvek Envelope, 12.5 x 15.5 
EP13F Express Mail=Flat Rate Envelope, 12.5 x 9.5 
	;
;Priority Mail 
0-1095 Priority Mail=Box, 12.25 x 15.5 x 3 
0-1096 Priority Mail=Video, 8.25 x 5.25 x 1.5 
0-1097 Priority Mail=Box, 11.25 x 14 x 2.25 
0-1098 Priority Mail=Tube, 6 x 38 
EP14 Priority Mail=Tyvek Envelope, 12.5 x 15.5 
EP14F Priority Mail=Flat Rate Envelope, 12.5 x 9.5 



[country codes]
    ;
    ; USPS International country codes/names
    ;
AL=Albania
DZ=Algeria
AS=American Samoa
AD=Andorra
AI=Anguilla
AG=Antigua and Barbuda
AR=Argentina
AW=Aruba
AU=Australia
AT=Austria
AP=Azores
AP=Azores (Portugal)
BS=Bahamas
BH=Bahrain
BD=Bangladesh
BB=Barbados
BY=Belarus
BE=Belgium
BZ=Belize
BJ=Benin
BM=Bermuda
BO=Bolivia
BL=Bonaire (Netherlands Antilles)
BW=Botswana
BR=Brazil
VG=British Virgin Islands
BN=Brunei Darussalam
BG=Bulgaria
BF=Burkina Faso
BI=Burundi
KH=Cambodia
CM=Cameroon
CA=Canada
CE=Canary Islands (Spain)
KY=Cayman Islands
CF=Central African Republic
TD=Chad
NN=Channel Islands (Jersey, Guernsey, Alderney and Sark) (Great Britain)
CL=Chile
CO=Colombia
CG=Congo (Brazzaville),Republic of the
CG=Congo, Democratic Republic of the
CK=Cook Islands (New Zealand)
CR=Costa Rica
HR=Croatia
CB=Curacao (Netherlands Antilles)
CY=Cyprus
CZ=Czech Republic
DK=Denmark
DJ=Djibouti
DM=Dominica
DM=Dominican Republic
EC=Ecuador
EG=Egypt
SV=El Salvador
EN=England (Great Britain and Northern Ireland)
ER=Eritrea
EE=Estonia
ET=Ethiopia
FM=Federated States of Micronesia
FJ=Fiji
FI=Finland
FR=France
FR=France, Metropolitan (France)
GF=French Guiana
PF=French Polynesia
GA=Gabon
GM=Gambia
GE=Georgia, Republic of
DE=Germany
GH=Ghana
GI=Gibraltar
GR=Greece
GL=Greenland
GD=Grenada
GP=Guadeloupe
GU=Guam
GT=Guatemala
GN=Guinea
GN=Guinea-Bissau
GY=Guyana
HT=Haiti
HO=Holland (Netherlands)
HN=Honduras
HK=Hong Kong
HU=Hungary
IS=Iceland
IN=India
ID=Indonesia
IL=Israel
IT=Italy
JM=Jamaica
JP=Japan
JO=Jordan
KZ=Kazakhstan
KE=Kenya
KI=Kiribati
KO=Kosrae, Micronesia
KW=Kuwait
KG=Kyrgyzstan
LA=Laos
LV=Latvia
LB=Lebanon
LS=Lesotho
LR=Liberia
LI=Liechtenstein
LT=Lithuania
LU=Luxembourg
MO=Macau (Macao)
MK=Macedonia, Republic of
MG=Madagascar
ME=Madeira Islands (Portugal)
MW=Malawi
MY=Malaysia
MV=Maldives
ML=Mali
MT=Malta
MH=Marshall Islands
MQ=Martinique
MR=Mauritania
MU=Mauritius
MX=Mexico
MD=Moldova
MC=Monaco (France)
MS=Montserrat
MA=Morocco
MZ=Mozambique
MM=Myanmar (Burma)
NA=Namibia
NP=Nepal
NL=Netherlands
NL=Netherlands Antilles
NL=Netherlands West Indies (Netherlands Antilles)
NC=New Caledonia
NZ=New Zealand
NI=Nicaragua
NE=Niger
NE=Nigeria
NF=Norfolk Island (Australia)
NB=Northern Ireland (Great Britain and Northern Ireland)
MP=Northern Mariana Islands, Commonwealth of
NO=Norway
OM=Oman
PK=Pakistan
PW=Palau
PA=Panama
PG=Papua New Guinea
PY=Paraguay
PE=Peru
PH=Philippines
PL=Poland
PT=Portugal
PR=Puerto Rico
QA=Qatar
RE=Reunion
RO=Romania
RT=Rota, Northern Mariana Islands (US Possession)
RU=Russia
RW=Rwanda
SS=Saba (Netherlands Antilles)
SS=Sabah (Malaysia)
SP=Saipan, Northern Mariana Islands (US Possession)
SA=Saudi Arabia
SF=Scotland (Great Britain and Northern Ireland)
SN=Senegal
SC=Seychelles
SL=Sierra Leone
SG=Singapore
SI=Slovenia
SB=Solomon Islands
ZA=South Africa
KR=South Korea (Korea, Republic of)
ES=Spain
LK=Sri Lanka
SW=St. Christopher and Nevis
EU=St. Eustatius (Netherlands Antilles)
LC=St. Lucia
MB=St. Maarten (Netherlands Antilles)
TB=St. Martin (Guadeloupe)
VC=St. Vincent and the Grenadines
SD=Sudan
SR=Suriname
SZ=Swaziland
SE=Sweden
CH=Switzerland
SY=Syrian Arab Republic
TA=Tahiti (French Polynesia)
TW=Taiwan
TJ=Tajikistan
TZ=Tanzania
TH=Thailand
TI=Tinian, Northern Mariana Islands(US Possession)
TG=Togo
TO=Tonga
TO=Tongareva (New Zealand)
TT=Trinidad and Tobago
TU=Truk (See Chuuk Island)
TN=Tunisia
TR=Turkey
TC=Turks and Caicos Islands
TV=Tuvalu
UG=Uganda
UA=Ukraine
AE=United Arab Emirates
GB=United Kingdom (Great Britain)
UY=Uruguay
UZ=Uzbekistan
VU=Vanuatu
VE=Venezuela
VN=Vietnam
WK=Wake Island
WL=Wales (Great Britain and Northern Ireland)
WF=Wallis and Futuna Islands
WS=Western Samoa
YA=Yap, Micronesia
ZM=Zambia
ZW=Zimbabwe



