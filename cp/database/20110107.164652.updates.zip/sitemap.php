<?php
include_once("include/startup.inc.php");
$link = mysql_connect(DB_HOST, DB_USERNAME, DB_PASSWORD);
@mysql_select_db(DB_NAME,$link);

$rs = @mysql_query("SELECT `value` FROM config WHERE `key` = 'web_site_url'", $link);
$cf = @mysql_fetch_array($rs, MYSQL_ASSOC);
$website_url = $cf['value'];

function dateDiff($dformat, $endDate, $beginDate){
	$date_parts1=explode($dformat, $beginDate);
	$date_parts2=explode($dformat, $endDate);
	$start_date=gregoriantojd($date_parts1[1], $date_parts1[2], $date_parts1[0]);
	$end_date=gregoriantojd($date_parts2[1], $date_parts2[2], $date_parts2[0]);
	return $end_date - $start_date;
}

// initialize the program and read the config(s)
include_once("include/initialize.inc");
$init = new Initialize();

$categories = array();
$records = array();

$sql = "SELECT products.sku,products.name,products.last_modified,
		product_categories.*, categories.category_name
		FROM products,product_categories,categories
		WHERE product_categories.pid = products.pid
		AND categories.catid = product_categories.catid";

$rs = @mysql_query($sql, $link);
while($row = @mysql_fetch_array($rs, MYSQL_ASSOC)){
	$categories[$row['catid']] = $row['category_name'];
	$records[$row['catid']][] = array($row['sku'],$row['name'],$row['last_modified']);
}

if(count($categories) > 0){

	if(file_exists("sitemap.xml")){
		unlink("sitemap.xml");
	}

	$fp = fopen('sitemap.xml', 'w');

	fwrite($fp, "<?xml version='1.0' encoding='UTF-8'?>\n");
	fwrite($fp, "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9'>\n");

	$today = date("Y-m-d");
	$linkCount = 0;

	foreach($categories as $catid=>$desc){

		$priority = '0.8';

		// category page
		$linkCount++;
		fwrite($fp,"<url>\n");
		fwrite($fp,"<loc>$website_url/products.php?catid=$catid&amp;category=" . urlencode($desc) . "</loc>\n");
		fwrite($fp,"<lastmod>$today</lastmod>\n");
		fwrite($fp,"<changefreq>monthly</changefreq>\n");
		fwrite($fp,"<priority>$priority</priority>\n");
		fwrite($fp,"</url>\n");

		// pages in the category
		foreach($records[$catid] as $index=>$flds){

			$sku = urlencode($flds[0]);
			$name = urlencode($flds[1]);
			$modified = $flds[2];

			if(!empty($modified)){

				$diff = dateDiff("-", $today, $modified);

				switch($diff){
					case ($diff < 15):
						$priority = '1.0';
						break;
					case ($diff >= 15 && $diff < 30):
						$priority = '0.8';
						break;
					case ($diff >= 30):
						$priority = '0.6';
						break;
				}
			}

			$linkCount++;
			fwrite($fp,"<url>\n");
			fwrite($fp,"<loc>$website_url/products.php?sku=$sku&amp;detail=true&amp;desc=$name</loc>\n");
			fwrite($fp,"<lastmod>$today</lastmod>\n");
			fwrite($fp,"<changefreq>daily</changefreq>\n");
			fwrite($fp,"<priority>$priority</priority>\n");
			fwrite($fp,"</url>\n");
		}
	}
	fwrite($fp,"</urlset>\n\n");
	fclose($fp);
}
?>
<p>Sitemap wrote <?php echo $linkCount;?> records <a href="sitemap.xml">sitemap.xml</a></p>


