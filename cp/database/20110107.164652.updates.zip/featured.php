<?php
$_REQUEST['category'] = "featured";

// initialize the program and read the config
include_once("include/initialize.inc");
$init = new Initialize();

// Set display format
$numberOfColumns = $_CF['product_display']['number_of_columns_to_display'];
$columnIndex = 1;
$thumbDir = $_CF['images']['thumbnail_images_directory'];
$border = $_CF['images']['image_border_size'];

// load the cart
$cart = $_Registry->LoadClass('cart');
$cart->initialize();

// Load display class
$display = $_Registry->LoadClass("Display");
// run the query
$display->runQuery();
?>
<?php if(count($display->records) > 0):?>

<table border="0" cellpadding="3" cellspacing="0" width="95%" ID="search.results">
    <tbody id="records">
        <tr>
            <?php foreach($display->records as $index=>$fields): ?>
                <?php
                    // if image is missing, it will try to use the no_photo image
                    // setting from the configuration automatically if the file exists
                    $image = null;
                    if(!empty($fields['images']['thumbnail']['image'])){
                        $thumb = $fields['images']['thumbnail']['image'];
                        $tWidth = $fields['images']['thumbnail']['width'];
                        $tHeight = $fields['images']['thumbnail']['height'];
                        $alt = "Image of " . $fields['name'];
                        if(file_exists("$thumbDir/$thumb")){
                            $image = "<img src=\"$thumbDir/$thumb\" height=\"$tHeight\" width=\"$tWidth\" border=\"$border\" alt=\"$alt\">";
                        }
                    }
                ?>
                <td align="center" valign="bottom" height="150px">
                    <table border=0 width="160" style="height:150px;" ID="Table2">
                        <tr>
                            <td align="center" valign="top">
                                <?php if($image):?>
                                    <a href="products.php?catid=<?=$fields['catid'];?>&amp;pid=<?=$fields['pid'];?>&amp;detail=true"><?=$image;?></a>
                                <?php endif;?>
                            </td>
                        </tr>
                        <tr>
                            <td align="center" valign="bottom">
                            <a href="products.php?catid=<?=$fields['catid'];?>&amp;pid=<?=$fields['pid'];?>&amp;detail=true"><?=$fields['name'];?></a>
                            </td>
                        </tr>
                        <?php if($_CF['product_display']['show_prices']):?>
                        <tr>
                            <td align="center" valign="bottom">Price: <?=$_Common->format_price($fields['price'],true);?></td>
                        </tr>
                        <?php endif;?>
                    </table>
                </td>

                <?php
                    if($columnIndex == $numberOfColumns && $index != (count($display->records)-1)){
                        print "</tr><tr>\n";
                        $columnIndex = 1;
                    }
                    else{
                        $columnIndex++;
                    }
                ?>

            <?php endforeach;?>
        </tr>
    </tbody>
</table>
<?php endif;?>