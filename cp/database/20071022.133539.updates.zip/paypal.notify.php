<?php
$debug = false;

// initialize the program and read the config(s)
include_once("include/initialize.inc");
$init = new Initialize();
global $_DB;

	// read	the	post from PayPal system	and	add	'cmd'
	$req = 'cmd=_notify-validate';

	foreach($_POST as $key => $value) {
		$value = urlencode(stripslashes($value));
		$req .=	"&$key=$value";
	}

	if($debug){
		logResult("Notify:\n" . parseString($req) . "\n\n");
	}

	// post	back to	PayPal system to validate
	$header	.= "POST /cgi-bin/webscr HTTP/1.0\r\n";
	$header	.= "Content-Type: application/x-www-form-urlencoded\r\n";
	$header	.= "Content-Length:	" .	strlen($req) . "\r\n\r\n";
	$fp	= fsockopen('www.paypal.com', 80, $errno, $errstr,	30);

	// retrieve payment status
	$payment_status	= $_POST['payment_status'];
	$payment_gross = $_POST['mc_gross'];
	$payer_email = $_POST['receiver_email'];

	if(!$fp) {
		// HTTP	ERROR
		logResult("HTTP	ERROR: Could not connect to PayPal for return IPN");
		exit;
	}
	else{

		$ppid = $_POST['custom'];
		fputs ($fp,	$header	. $req);
		$res = "";
		while (!feof($fp)) {
			$res .= fgets ($fp, 1024);
		}
		fclose ($fp);
	}

	if($debug){
		logResult("\n\nResponse:\n" . $res . "\n\n");
	}


	// process payment
	if(strstr($res, "VERIFIED")){

		//logResult("\n\nVERIFIED = true\n");

		// Check the payment amounts
		$sql = "SELECT payment_gross FROM paypal WHERE ppid = '$ppid' LIMIT 1";
		$data = array();
		$data = $_DB->getRecord($sql);
		
		if(count($data) == 0){
			sendSuspiciousEmail(parseString($req),"Could not find matching paypal table entry for the IPN results.");
			exit;
		}
		
		if(!empty($data['payment_gross']) && doubleval($data['payment_gross']) != doubleval($payment_gross)){
			$payment_status = "Paypal payment amount does not match submitted amount. Possible Fraud.";
			sendSuspiciousEmail(parseString($req),$payment_status);
		}
		
		$sql = "UPDATE paypal SET payment_status = '$payment_status', payer_email = '$payer_email'";
		if(!empty($_POST['memo'])){
			$memo = $_POST['memo'];
			$sql .= "memo = '$memo'";
		}
		$sql .= " WHERE ppid = '$ppid'";
		$_DB->execute($sql);
	}
	elseif(strstr($res, "INVALID")){
		$sql = "UPDATE paypal SET payment_status = 'Invalid' WHERE ppid = '$ppid'";
		$_DB->execute($sql);
		// log for manual investigation
		logResult("Request:\n" . parseString($req) . "\n\nResponse:\n" . parseString($res) . "\n\n");
	}

	if($debug){
		logResult("Request:\n" . parseString($req) . "\n\nResponse:\n" . parseString($res) . "\n\n");
	}
	exit;
	
	// ----------------------------------------------------
	function logResult($result){
		global $debug;
		if($debug){
			$date = "\n\n" . date("m/d/Y") . "\n";
			if(getenv("windir") != ""){
				$result = str_replace("\n","\r\n",$result);
			}
			$R = fopen("pp.results.log","a");
			fputs($R,$result);
			fclose($R);	
		}
	}
	// --------------------------------------------------------------
	function parseString($res){
		$pairs = split("&",$res);
		$parsed = array();
		foreach($pairs as $i=>$pair){
			@list($name,$val) = split("=",$pair);
			$parsed[$name] = $val;
		}
		//ksort($parsed);
		return print_r($parsed,true);		
	}
	
	// --------------------------------------------------------------
	function sendSuspiciousEmail($result,$comments){
		global $_Registry;
		global $_CF;
		$email = $_Registry->loadClass('email');
		$storeEmail = $_CF['email']['store_owner_email_address'];
		
		$subject = "Suspicious PayPal Payment";
		$Html = "<html><body><pre>\r\n$comments\r\n\r\n";
		$Html .= $result;
		$Html .= "</pre></body></html>\r\n";
		$email->send($storeEmail, $storeEmail, $subject, $Html, NULL);
	}

	
	
?>