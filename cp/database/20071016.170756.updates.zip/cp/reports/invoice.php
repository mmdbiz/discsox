<?php
$_isAdmin = true;
$_adminFunction = "reports";

// initialize the program, read the config(s) and set include paths
include_once("../../include/initialize.inc");
$init = new Initialize(true);

$login = $_Registry->LoadClass("admin_login");
$login->CheckLogin();

$_Form = $_Registry->LoadClass("form");
include_once("include/orders.inc");

getDetailRecords();

$color = array();
$color[~0] = "#e2eDe2";
$color[0] = "#FFFFFF";
$ck = 0;
$payMethod = null;
if(!empty($order[0]['payment_method'])){
	@list($payMethod,$ext) = explode('.',$order[0]['payment_method']);
}

error_reporting(E_PARSE|E_WARNING);
ob_start();
include_once("../templates/invoice.html");
$template = ob_get_contents();
ob_end_clean();
error_reporting(E_ALL);
?>
<?=$template;?>
