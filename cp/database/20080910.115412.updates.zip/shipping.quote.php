<?php
$debug = false;
// initialize the program and read the config
include_once("include/initialize.inc");
$init = new Initialize();

// check if login is required
if($_CF['login']['require_login']){
	$login = $_Registry->LoadClass('login');
	$login->checkLogin();
}

$cart = $_Registry->LoadClass('cart');
$cart->LoadCart();

$shippingPlugins = array();
// check the shipping table to see if Shipping Plugin Name is added and
// "Use Shipping Plugin" is on. If so, try to dynamically load it here
$shipExt = $_DB->getRecord("SELECT use_shipping_plugin,shipping_plugin_name FROM shipping");
if($shipExt['use_shipping_plugin'] == 'true' && trim($shipExt['shipping_plugin_name']) != ""){
	$fileNames = explode(',',trim($shipExt['shipping_plugin_name']));
	foreach($fileNames as $i=>$name){
		$flds = explode('.',$name);
		$shippingPlugins[] = $flds[0];	
	}
}

$haveRates = false;
$noRates = false;
if(!empty($_REQUEST['quote']) && count($_CART) > 0){
	foreach($_REQUEST as $key=>$value){
		if(substr($key,0,11) == "shipaddress"){
			if(is_array($value)){
				$_SESSION[$key] = $value;
			}
			else{
				$_SESSION[$key] = trim($value);
			}
		}
	}
	
	if(count($shippingPlugins) > 0){
		$fileNames = explode(',',trim($shipExt['shipping_plugin_name']));
		$plugin = $fileNames[0];
		if(!empty($_REQUEST['preferred_shipper'])){
			$_SESSION['preferred_shipper'] = trim($_REQUEST['preferred_shipper']);
		}
		if(count($fileNames) > 1){
			foreach($fileNames as $i=>$name){
				if(!empty($_SESSION['preferred_shipper']) && substr($name,0,strlen($_SESSION['preferred_shipper'])) == $_SESSION['preferred_shipper']){
					$plugin = trim($name);
					break;
				}
			}
		}
		if($debug){
			$_Common->debugPrint($plugin,"Selected Shipping Plug-in");
		}
		if($_Registry->file_exists_incpath($plugin)){
			$_Registry->registeredClasses['shipping.rates.inc'] = $plugin;
		}
	}

	$shippers = $_Registry->LoadClass('Shipping.Rates');
	
	$shippers->Country = $_REQUEST['shipaddress_country'];
	if($_REQUEST['shipaddress_country'] == "US" || $_REQUEST['shipaddress_country'] == "CA"){
		$shippers->State = $_REQUEST['shipaddress_state'];
	}
	if(!empty($_REQUEST['shipaddress_postalcode'])){
		$shippers->Zip = $_REQUEST['shipaddress_postalcode'];
	}
	
	@list($shippingRateList,$shippingRate) = $shippers->GetShippingRateList();
	
	if(count($shippingRateList) > 0){
		$haveRates = true;	
	}
	else{
		$noRates = true;	
	}
}
error_reporting(E_PARSE|E_WARNING);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>Shipping Quote</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<link rel="stylesheet" type="text/css" href="styles/cart.styles.css" />
	</head>
<body>

<div align="center">

<?php if(count($_CART) > 0):?>

	<script LANGUAGE="JavaScript">
		var requiredFields = new Array('shipaddress_country','shipaddress_state','shipaddress_postalcode');
		var selectedShipCountry = "<?=$_SESSION['shipaddress_country'];?>";
		var selectedShipState = "<?=$_SESSION['shipaddress_state'];?>";
		var selectedBillState = "";
		var counties = new Array();
		function testFields(form){
			var country = form.elements['shipaddress_country'].options[form.elements['shipaddress_country'].selectedIndex].value;
			if(country != 'US' && country != 'CA'){
				requiredFields.pop();
			}
			return testRequiredFields(form);
		}
		
		var hideareacode = true;
		<?php if(isset($_CF['basics']['always_display_area_code']) && $_CF['basics']['always_display_area_code']):?>
			hideareacode = false;
		<?php endif;?>
		
	</script>
	<script LANGUAGE="JavaScript" src="javascripts/checkout.js"></script>

	<style>
	td{
		vertical-align: middle;
		align: left;
	}
	.topAlign{
		vertical-align: top;
	}
	</style>

	<form name="quote" id="quote" method="get" action="shipping.quote.php">

	<table border="0" cellspacing="0" cellpadding="2" width="500" align="center" ID="Table1">
		<tr>
			<td colspan="2" align="left">
				<h4>Get Shipping Quote</h4>
				<p>Please complete the following information for available shipping methods and rates.<br /><br /></p>
			</td>
		</tr>
		<tr>
			<td align="right" width="40%">Select Ship to Country: </td>
			<td width="60%" align="left">
    			<select NAME="shipaddress_country" onChange="checkCountry(this.form,this.name);" ID="Select1">
    				<option value="US" selected>United States </option>
    				<option value="AL">Albania </option>
    				<option value="DZ">Algeria </option>
    				<option value="AS">American Samoa </option>
    				<option value="AD">Andorra </option>
    				<option value="AI">Anguilla </option>
    				<option value="AG">Antigua &amp; Barbuda </option>
    				<option value="AR">Argentina </option>
    				<option value="AW">Aruba </option>
    				<option value="AU">Australia </option>
    				<option value="AT">Austria </option>
    				<option value="AP">Azores </option>
    				<option value="BS">Bahamas </option>
    				<option value="BH">Bahrain </option>
    				<option value="BD">Bangladesh </option>
    				<option value="BB">Barbados </option>
    				<option value="BE">Belgium </option>
    				<option value="BZ">Belize </option>
    				<option value="BY">Belarus </option>
    				<option value="BJ">Benin </option>
    				<option value="BM">Bermuda </option>
    				<option value="BO">Bolivia </option>
    				<option value="BL">Bonaire </option>
    				<option value="BW">Botswana </option>
    				<option value="BR">Brazil </option>
    				<option value="VG">British Virgin Islands </option>
    				<option value="BN">Brunei </option>
    				<option value="BG">Bulgaria </option>
    				<option value="BF">Burkina Faso </option>
    				<option value="BI">Burundi </option>
    				<option value="KH">Cambodia </option>
    				<option value="CM">Cameroon </option>
    				<option value="CA">Canada </option>
    				<option value="CE">Canary Islands </option>
    				<option value="CV">Cape Verde Islands </option>
    				<option value="KY">Cayman Islands </option>
    				<option value="CF">Central African Republic </option>
    				<option value="TD">Chad </option>
    				<option value="NN">Channel Islands </option>
    				<option value="CL">Chile </option>
    				<option value="CN">China, Peoples Republic of </option>
    				<option value="CO">Colombia </option>
    				<option value="CG">Congo </option>
    				<option value="CK">Cook Islands </option>
    				<option value="CR">Costa Rica </option>
    				<option value="HR">Croatia </option>
    				<option value="CB">Curacao </option>
    				<option value="CY">Cyprus </option>
    				<option value="CZ">Czech Republic </option>
    				<option value="DK">Denmark </option>
    				<option value="DJ">Djibouti </option>
    				<option value="DM">Dominica </option>
    				<option value="DO">Dominican Republic </option>
    				<option value="EC">Ecuador </option>
    				<option value="EG">Egypt </option>
    				<option value="SV">El Salvador </option>
    				<option value="EN">England </option>
    				<option value="GQ">Equitorial Guinea </option>
    				<option value="ER">Eritrea </option>
    				<option value="EE">Estonia </option>
    				<option value="ET">Ethiopia </option>
    				<option value="FO">Faeroe Islands </option>
    				<option value="FM">Federated States of Micronesia </option>
    				<option value="FJ">Fiji </option>
    				<option value="FI">Finland </option>
    				<option value="FR">France </option>
    				<option value="GF">French Guiana </option>
    				<option value="PF">French Polynesia </option>
    				<option value="GA">Gabon </option>
    				<option value="GM">Gambia </option>
    				<option value="GE">Georgia </option>
    				<option value="DE">Germany </option>
    				<option value="GH">Ghana </option>
    				<option value="GI">Gibraltar </option>
    				<option value="GR">Greece </option>
    				<option value="GL">Greenland </option>
    				<option value="GD">Grenada </option>
    				<option value="GP">Guadeloupe </option>
    				<option value="GU">Guam </option>
    				<option value="GT">Guatemala </option>
    				<option value="GN">Guinea </option>
    				<option value="GW">Guinea-Bissau </option>
    				<option value="GY">Guyana </option>
    				<option value="HT">Haiti </option>
    				<option value="HO">Holland </option>
    				<option value="HN">Honduras </option>
    				<option value="HK">Hong Kong </option>
    				<option value="HU">Hungary </option>
    				<option value="IS">Iceland </option>
    				<option value="IN">India </option>
    				<option value="ID">Indonesia </option>
    				<option value="IL">Israel </option>
    				<option value="IT">Italy </option>
    				<option value="CI">Ivory Coast </option>
    				<option value="JM">Jamaica </option>
    				<option value="JP">Japan </option>
    				<option value="JO">Jordan </option>
    				<option value="KZ">Kazakhstan </option>
    				<option value="KE">Kenya </option>
    				<option value="KI">Kiribati </option>
    				<option value="KO">Kosrae </option>
    				<option value="KW">Kuwait </option>
    				<option value="KG">Kyrgyzstan </option>
    				<option value="LA">Laos </option>
    				<option value="LV">Latvia </option>
    				<option value="LB">Lebanon </option>
    				<option value="LS">Lesotho </option>
    				<option value="LR">Liberia </option>
    				<option value="LI">Liechtenstein </option>
    				<option value="LT">Lithuania </option>
    				<option value="LU">Luxembourg </option>
    				<option value="MO">Macau </option>
    				<option value="MK">Macedonia </option>
    				<option value="MG">Madagascar </option>
    				<option value="ME">Madeira </option>
    				<option value="MW">Malawi </option>
    				<option value="MY">Malaysia </option>
    				<option value="MV">Maldives </option>
    				<option value="ML">Mali </option>
    				<option value="MT">Malta </option>
    				<option value="MH">Marshall Islands </option>
    				<option value="MQ">Martinique </option>
    				<option value="MR">Mauritania </option>
    				<option value="MU">Mauritius </option>
    				<option value="MX">Mexico </option>
    				<option value="MD">Moldova </option>
    				<option value="MC">Monaco </option>
    				<option value="MS">Montserrat </option>
    				<option value="MA">Morocco </option>
    				<option value="MZ">Mozambique </option>
    				<option value="MM">Myanmar </option>
    				<option value="NA">Namibia </option>
    				<option value="NP">Nepal </option>
    				<option value="NL">Netherlands </option>
    				<option value="AN">Netherlands Antilles </option>
    				<option value="NC">New Caledonia </option>
    				<option value="NZ">New Zealand </option>
    				<option value="NI">Nicaragua </option>
    				<option value="NE">Niger </option>
    				<option value="NG">Nigeria </option>
    				<option value="NF">Norfolk Island </option>
    				<option value="NB">Northern Ireland </option>
    				<option value="MP">Northern Mariana Islands </option>
    				<option value="NO">Norway </option>
    				<option value="OM">Oman </option>
    				<option value="PK">Pakistan </option>
    				<option value="PW">Palau </option>
    				<option value="PA">Panama </option>
    				<option value="PG">Papua New Guinea </option>
    				<option value="PY">Paraguay </option>
    				<option value="PE">Peru </option>
    				<option value="PH">Philippines </option>
    				<option value="PL">Poland </option>
    				<option value="PO">Ponape </option>
    				<option value="PT">Portugal </option>
    				<option value="PR">Puerto Rico </option>
    				<option value="QA">Qatar </option>
    				<option value="IE">Republic of Ireland </option>
    				<option value="YE">Republic of Yemen </option>
    				<option value="RE">Reunion </option>
    				<option value="RO">Romania </option>
    				<option value="RT">Rota </option>
    				<option value="RU">Russia </option>
    				<option value="RW">Rwanda </option>
    				<option value="SS">Saba </option>
    				<option value="SP">Saipan </option>
    				<option value="SA">Saudi Arabia </option>
    				<option value="SF">Scotland </option>
    				<option value="SN">Senegal </option>
    				<option value="SC">Seychelles </option>
    				<option value="SL">Sierra Leone </option>
    				<option value="SG">Singapore </option>
    				<option value="SK">Slovakia </option>
    				<option value="SI">Slovenia </option>
    				<option value="SB">Solomon Islands </option>
    				<option value="ZA">South Africa </option>
    				<option value="KR">South Korea </option>
    				<option value="ES">Spain </option>
    				<option value="LK">Sri Lanka </option>
    				<option value="NT">St. Barthelemy </option>
    				<option value="SW">St. Christopher </option>
    				<option value="SX">St. Croix </option>
    				<option value="EU">St. Eustatius </option>
    				<option value="UV">St. John </option>
    				<option value="KN">St. Kitts &amp; Nevis </option>
    				<option value="LC">St. Lucia </option>
    				<option value="MB">St. Maarten </option>
    				<option value="TB">St. Martin </option>
    				<option value="VL">St. Thomas </option>
    				<option value="VC">St. Vincent &amp; the Grenadines </option>
    				<option value="SD">Sudan </option>
    				<option value="SR">Suriname </option>
    				<option value="SZ">Swaziland </option>
    				<option value="SE">Sweden </option>
    				<option value="CH">Switzerland </option>
    				<option value="SY">Syria </option>
    				<option value="TA">Tahiti </option>
    				<option value="TW">Taiwan </option>
    				<option value="TJ">Tajikistan </option>
    				<option value="TZ">Tanzania </option>
    				<option value="TH">Thailand </option>
    				<option value="TI">Tinian </option>
    				<option value="TG">Togo </option>
    				<option value="TO">Tonga </option>
    				<option value="TL">Tortola </option>
    				<option value="TT">Trinidad &amp; Tobago </option>
    				<option value="TU">Truk </option>
    				<option value="TN">Tunisia </option>
    				<option value="TR">Turkey </option>
    				<option value="TC">Turks &amp; Caicos Islands </option>
    				<option value="TV">Tuvalu </option>
    				<option value="UG">Uganda </option>
    				<option value="UA">Ukraine </option>
    				<option value="UI">Union Island </option>
    				<option value="AE">United Arab Emirates </option>
    				<option value="GB">United Kingdom </option>
    				<option value="UY">Uruguay </option>
    				<option value="VI">US Virgin Islands </option>
    				<option value="UZ">Uzbekistan </option>
    				<option value="VU">Vanuatu </option>
    				<option value="VE">Venezuela </option>
    				<option value="VN">Vietnam </option>
    				<option value="VR">Virgin Gorda </option>
    				<option value="WK">Wake Island </option>
    				<option value="WL">Wales </option>
    				<option value="WF">Wallis &amp; Futuna Islands </option>
    				<option value="WS">Western Samoa </option>
    				<option value="YA">Yap </option>
    				<option value="ZR">Zaire </option>
    				<option value="ZM">Zambia </option>
    				<option value="ZW">Zimbabwe </option>
    			</select>
			</td>
		</tr>
		<tr>
			<td align="right" width="40%">Select State/Province: </td>
			<td width="60%" align="left">
				<select NAME="shipaddress_state" onChange="addCounties(this.form,this.name);" ID="Select2">
					<option value="INVALID">Select State</option>
				</select>
			</td>
		</tr>
		<tr>
			<td align="right" width="40%">Enter Postal Code if applicable: </td>
			<td width="60%" align="left">
				<input type="text" size="25" name="shipaddress_postalcode" maxlength="10" value="<?=$_SESSION['shipaddress_postalcode'];?>">
			</td>
		</tr>
		<?php if(count($shippingPlugins) > 1):?>
		<tr>
			<td align="right" width="36%">Preferred Shipping Method: </td>
			<td width="64%" align="left">
				<select name="preferred_shipper">
				<?php foreach($shippingPlugins as $k=>$shipper):?>
					<?php if($_SESSION['preferred_shipper'] == $shipper):?>
						<option value="<?=$shipper;?>" selected><?=strtoupper($shipper);?></option>
					<?php else:?>
						<option value="<?=$shipper;?>"><?=strtoupper($shipper);?></option>
					<?php endif;?>
				<?php endforeach;?>
				</select>
			</td>
		</tr>
		<?php endif;?>
		<tr><td colspan="2" width="100%">&nbsp;</td></tr>
		<tr>
			<td colspan="2" width="100%" align="center"><br />
				<input name="quote" class="buttons" type="submit" value="Get Quote" onClick="return testFields(this.form);">
			</td>
		</tr>
		<tr><td colspan="2" width="100%">&nbsp;</td></tr>
	</table>

	<?php if($haveRates):?>
		<br clear="all" />
		<table border="0" cellspacing="0" cellpadding="2" width="500" align="center" ID="Table1">
			<tr>
				<td align="left">
					<h4>Available Shipping Rates at Checkout</h4>
				</td>
			</tr>
			<?php foreach($shippingRateList as $carrier=>$rate):?>
			<tr>
				<td align="left" style="padding-left:20px;"><li><?=$carrier;?> - <?=$_Common->format_price($rate,true);?></td>
			</tr>
			<?php endforeach;?>
		</table>	
	<?php elseif($noRates):?>
		<p><b>No shipping rates were returned for the values you entered.</b></p>
	<?php endif;?>
		
	</form>

	<script LANGUAGE="JavaScript">
		selectBoxes(document.forms['quote'],true);
	</script>

<?php else:?>

	<p><br /><br /><b>Your cart is currently empty. Cannot supply shipping quote at this time.</b></p>

<?php endif;?>

</div>
<p>&nbsp;</p>
</body>
</html>
	