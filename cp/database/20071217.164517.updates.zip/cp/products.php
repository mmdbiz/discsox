<?php
//VersionInfo:Version[3.0.1]
// update

$_isAdmin = true;
$_adminFunction = "products";

// initialize the program and read the config(s)
include_once("../include/initialize.inc");
$init = new Initialize();

global $_Registry;
$login = $_Registry->LoadClass("admin_login");
$login->CheckLogin();

$maxPerScreen = 50;
$hits = 0;
if(!empty($_REQUEST['hits'])){
	$hits = intval($_REQUEST['hits']);	
}

$data = array();
$add = false;
$edit = false;
$vars = array();
$fldProperties = array();

$prodClass = $_Registry->LoadClass("products");

// clear empty files
if(count($_FILES) > 0){
	foreach($_FILES	as $fldname=>$properties){
		if($properties['tmp_name'] == ""){
			unset($_FILES[$fldname]);	
		}
	}
}


	$RUN = false;
	foreach($_REQUEST as $key=>$value){
		switch($key){

			case "add":
			case "edit":
				$vars = $prodClass->editProducts();
				$edit = true;
				$RUN = 1;
				break;

			case "list":
				$vars = $prodClass->listProducts();
				$RUN = 1;
				break;

			case "update":
			case "insert":
				$prodClass->updateProducts();
				$edit = true;
				if(!empty($_REQUEST['show_add'])){
					// Go to add screen
					unset($_REQUEST['pid']);
					$_REQUEST['add'] = "true";
					$vars = $prodClass->editProducts(NULL);
				}
				else{
					// show edit screen
					$pid = $_REQUEST['pid'];
					$vars = $prodClass->editProducts($pid);
				}
				$RUN = 1;
				break;

			case "delete":
				$prodClass->deleteProducts();
				$vars = $prodClass->listProducts();
				$RUN = 1;
				break;
		}
		if($RUN){
			break;
		}
	}
	
	if(!$RUN){
		$vars = $prodClass->listProducts();
	}

if(isset($_REQUEST['add'])){
	$add = true;	
}

// row backround colors
$color = array();
$color[0] = "#FFFFFF";
$color[~0] = "#E2EDE2";
$ck = 0;

$haveInventory = $_Registry->file_exists_incpath("inventory.inc");
$shipExt = $_DB->getRecord("SELECT use_shipping_plugin,shipping_plugin_name FROM shipping");

if(!empty($shipExt['shipping_plugin_name'])){
	$names = explode('.',$shipExt['shipping_plugin_name']);
	$shipExt['shipping_plugin_name'] = strtoupper($names[0]);
	//$_Common->debugPrint($shipExt['shipping_plugin_name']);
}
?>
<html>
<head>
<title>Product List</title>
<script LANGUAGE="JavaScript">
//<!--
if(eval(parent.menu)) {
	var fileName = parent.menu.location.pathname.substring(parent.menu.location.pathname.lastIndexOf('/')+1);
	if(fileName != "products.menu.html"){
		<?php if($haveInventory):?>
		parent.menu.location = 'menus/products.menu.html?true';
		<?php else:?>
		parent.menu.location = 'menus/products.menu.html';
		<?php endif;?>
	}
}
sWidth = screen.width;
var styles = "admin.800.css";
if(sWidth > 850){
    styles = "admin.1024.css";
}
if(sWidth > 1024){
    styles = "admin.1152.css";
}
if(sWidth > 1100){
    styles = "admin.1280.css";
}
document.write('<link rel="stylesheet" href="stylesheets/' + styles + '" type="text/css">');

function showIt(whichEl){

    var imageID = "img." + whichEl;

    if(document.all){
        whichEl = document.all[whichEl];
        imageEl = document.all[imageID];
    }
    else{
        whichEl = document.getElementById(whichEl);
        imageEl = document.getElementById(imageID);
    }

    whichEl.style.display = (whichEl.style.display == "none" ) ? "" : "none";

        // Change images

    var imgPath = unescape(imageEl.src).split('/');
    var imgName = imgPath[imgPath.length - 1];
    if(imgName == "plus.gif"){
        imageEl.src = "images/minus.gif";
    }
    else{
        imageEl.src = "images/plus.gif";
    }
}

//-->
</script>
<script LANGUAGE="JavaScript" src="javascripts/products.js"></script>

</head>
<body class="mainForm">
<div align=center valign=top style="margin-top:10px;">

<?php if(count($data) == 0):?>

	<p>No products have been defined in the database.</p>

<?php elseif($edit):?>

	<?php error_reporting(E_PARSE|E_WARNING);?>

	<form id="frmMain" method=post action="products.php" enctype="multipart/form-data">
		
		<?php if(!empty($_REQUEST['add'])):?>
			<h4>Add New Product</h4>
			<input type=hidden name="insert" value="true">
		<?php else:?>
			<h4 style="line-height:10px;">Editing Item <?=$data['sku'];?> (<?=$data['name'];?>)</h4>
			<?php if($vars['navLinks']):?>
				<p><?=$vars['navLinks'];?></p>
			<?php endif;?>
			<input type=hidden name="pid" value="<?=$data['pid'];?>" ID="Hidden1">
			<input class=buttons type="submit" name="update" value="Update Product" onClick="return testEntries(this.form);"> &nbsp; 
			<input class=buttons type="submit" name="delete" value="Delete Product" onclick="return confirm('Are you sure you want to delete this product?')"><br /><br />
			
		<?php endif;?>

		<table border="1" cellpadding="3" cellspacing="0" ID="Table1" style="border-collapse:collapse;" width="600">

			<tr>
				<td width="10" valign="top"><img id="img.general" name="img.general" src="images/minus.gif" style="cursor:hand;" onClick="showIt('general');"></td>
		  		<td width="100%" align="left"><span style="cursor:hand;color:#800000" onClick="showIt('general');"><b>General Product Information</b></span></td>
			</tr>

			<tr id="general" style="display:;">
				<td colspan="2" align="center" valign="top">
					<table border="0" cellpadding="3" cellspacing="1" width="100%">
						<tr>
		  					<td align=right valign=top>Select Category:</td>
							<td align=left valign=top><b>NOTE:</b> Hold CTRL key and click to select more than one category<br><br>
								<?=$vars['parentSelectBox'];?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Manufacturer:</td>
							<td align=left valign=top>
								<?=$mfgSelect;?>
							</td>
						</tr>
	  					<?php if($vars['optionCount'] > 0 && empty($_REQUEST['add'])):?>
						<tr>
    	  					<td align=right valign=top>Product Options:</td>
							<td align=left valign=top>
								<input type=button value="Select Options" onClick="return OptionListWindow('<?=$data['pid'];?>','<?=$data['name'];?>','<?=session_id();?>')" ID="Button1" NAME="Button1">
								<?php if($vars['product_option_count'] > 0):?>
									&nbsp; (<?=$vars['product_option_count'];?> Options Selected)
								<?php endif;?>
							</td>
						</tr>
						<?php endif;?>
						<?php if(empty($_REQUEST['add'])):?>
						<tr>
    	  					<td align=right valign=top>Related Products:</td>
							<td align=left valign=top>
								<input type=button value="Select Products" onClick="return RelatedListWindow('<?=$data['pid'];?>','<?=$data['name'];?>','<?=session_id();?>')" ID="Button2" NAME="Button2">
							</td>
						</tr>
						<?php endif;?>	
						<tr>
		  					<td align=right valign=top>Display Product:</td>
							<td align=left valign=top>
								<?=$data['display_product'];?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>SKU:</td>
							<td align=left valign=top>
		    					<input type=text name="sku" value="<?=$data['sku'];?>" size=60 ID="Text1">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Name:</td>
							<td align=left valign=top>
		    					<input type=text name="name" value="<?=stripslashes($data['name']);?>" size=60 ID="Text2">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Retail Price:</td>
							<td align=left valign=top>
								<input type=text name="retail_price" value="<?=$data['retail_price'];?>" size=60 ID="Text3">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Website Price:</td>
							<td align=left valign=top>
		    					<input type=text name="price" value="<?=$data['price'];?>" size=60 ID="Text3">
		    					[<a href="#" onClick="return OpenQtyWindow('price')">Qty Price</a>]
							</td>
						</tr>	
						<tr>
		  					<td align=right valign=top>On Sale:</td>
							<td align=left valign=top>
								<?=$data['on_sale'];?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Description:</td>
							<td align=left valign=top>
		    					<textarea name="description" rows=10 cols=59 wrap=virtual ID="Textarea1"><?=stripslashes($data['description']);?></textarea>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Default Size:</td>
							<td align=left valign=top>
		    					<input type=text name="size" value="<?=$data['size'];?>" size=60 ID="Text5">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Weight:</td>
							<td align=left valign=top>
		    					<input type=text name="weight" value="<?=$data['weight'];?>" size=60 ID="Text6">
		    					<?php if($shipExt['use_shipping_plugin'] == 'true' && trim($shipExt['shipping_plugin_name']) != ""):?>
									<br />[<a href="#" onClick="return shipDefineWindow('weight','<?=$shipExt['shipping_plugin_name'];?>')">Define <?=$shipExt['shipping_plugin_name'];?> Package</a>]
								<?php endif;?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Link Page:</td>
							<td align=left valign=top>
		    					<input type=text name="link_page" value="<?=$data['link_page'];?>" size=60 ID="Text15">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Link Text:</td>
							<td align=left valign=top>
		    					<input type=text name="link_text" value="<?=$data['link_text'];?>" size=60 ID="Text16">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Is Taxable:</td>
							<td align=left valign=top>
								<?=$data['is_taxable'];?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Tax Rate:</td>
							<td align=left valign=top>
		    					<input class=rightalign type=text name="tax_rate" value="<?=$data['tax_rate'];?>" size="5" ID="Text7">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Is Downloadable:</td>
							<td align=left valign=top>
								<?=$data['is_downloadable'];?>
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Download Filename:</td>
							<td align=left valign=top>
		    					<input type="text" name="download_filename" value="<?=$data['download_filename'];?>" size=60 ID="Text7">
							</td>
						</tr>	
						<tr>
		  					<td align=right valign=top>Last Modified Date:</td>
							<td align=left valign=top>
								<?php if($data['last_modified'] != "" && $data['last_modified'] != "0000-00-00"):?>
    		    					<?=$data['last_modified'];?>
								<?php else:?>
    		    					<?=date("Y-m-d");?>
								<?php endif;?>
							</td>
						</tr>
						
						<?php if(isset($data['detail_page_title'])):?>
							<tr>
		  						<td align=right valign=top>Detail Page Title:</td>
								<td align=left valign=top>
		    						<input type="text" name="detail_page_title" value="<?=$data['detail_page_title'];?>" size=60 ID="Text7">
								</td>
							</tr>
						<?php endif;?>
						
						<?php if(isset($data['detail_meta_description'])):?>
							<tr>
		  						<td align=right valign=top nowrap>Detail Meta Description:</td>
								<td align=left valign=top>
		    						<textarea name="detail_meta_description" rows=5 cols=59 wrap=virtual ID="Textarea1"><?=stripslashes($data['detail_meta_description']);?></textarea>
								</td>
							</tr>
						<?php endif;?>
						
						<?php if(isset($data['detail_meta_keywords'])):?>
							<tr>
		  						<td align=right valign=top>Detail Meta Keywords:</td>
								<td align=left valign=top>
		    						<textarea name="detail_meta_keywords" rows=5 cols=59 wrap=virtual ID="Textarea1"><?=stripslashes($data['detail_meta_keywords']);?></textarea>
								</td>
							</tr>
						<?php endif;?>
						
						
						<tr><td colspan="2">&nbsp;</td></tr>
					</table>
				</td>
			</tr>

			<tr>
				<td width="10" valign="top"><img id="Img3" name="img.images" src="images/plus.gif" style="cursor:hand;" onClick="showIt('images');"></td>
		  		<td width="100%" align="left"><span style="cursor:hand;color=#800000;" onClick="showIt('images');"><b>Images</b></span></td>
			</tr>

			<tr id="images" style="display:none;">
			
				<td>&nbsp;</td>
				<td align="center" valign="top" style="border:1px solid #336699;">
				
	  				<table border="0" cellpadding=3 cellspacing=1 ID="Table4">
	  					<tr><td colspan=2>&nbsp;</td></tr>
						<tr>
		  					<td align=right valign=top>Thumbnail Image:</td>
							<td align=left valign=top>
		    					<input type=text name="thumbnail_image" value="<?=$data['thumbnail_image'];?>" size=40 ID="Text12">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Upload thumbnail_image:</td>
							<td>
								<input type="file" name="file-thumbnail_image" size=50 ID="File1">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Fullsize Image:</td>
							<td align=left valign=top>
		    					<input type=text name="fullsize_image" value="<?=$data['fullsize_image'];?>" size=40 ID="Text13">
							</td>
						</tr>
						<tr>
		  					<td align=right valign=top>Upload fullsize_image:</td>
							<td>
								<input type="file" name="file-fullsize_image" size=50 ID="File2">
							</td>
						</tr>
						<tr><td colspan=2>&nbsp;</td></tr>
						<tr>
		  					<td colspan=2 align=center>
		  					Automatically resize Fullsize image upload to <?=$_CF['images']['product_thumbnail_max_height'];?> high
							X <?=$_CF['images']['product_thumbnail_max_width'];?> wide and save as thumbnail?	
		  					</td>
						</tr>
						<tr>
		  					<td align=right valign=middle>Create Thumbnail:</td>
							<td>
								<input type=radio name="create_thumbnail" value="true" ID="Radio1"> Yes
								<input type=radio name="create_thumbnail" value="false" checked ID="Radio2"> No &nbsp;
							</td>
						</tr>
						<tr><td colspan=2>&nbsp;</td></tr>
	  				</table>

				</td>
			</tr>

			<?php if($vars['haveInventoryClass']):?>

				<tr>
					<td width="10" valign="top"><img id="Img6" name="img.inventory" src="images/plus.gif" style="cursor:hand;" onClick="showIt('inventory');"></td>
		  			<td width="100%" align="left"><span style="cursor:hand;color:#800000" onClick="showIt('inventory');"><b>Inventory for: <?=$data['name'];?></b></span></td>
				</tr>

				<tr id="inventory" style="display:none;">
				
					<td>&nbsp;</td>
					<td align="left" valign="top" style="border:1px solid #336699; padding-left:10px;">

						<p>You must set the item as an inventory item and save it before you can set the inventory values.</p>
						
						<table border=0 cellpadding=3 cellspacing=1 ID="Table7" align="center" width="98%">
							<tr>
		  						<td align=right valign="top" width="50%">Inventory Item:</td>
								<td align=left valign="top"  width="50%">
									<?=$data['inventory_item'];?>
								</td>
							</tr>
							<tr>
		  						<td align=right valign=top>Inventory Options:</td>
								<td align=left valign=top>
									<?=$data['inventory_options'];?>
								</td>
							</tr>
							<tr>
		  						<td align=right valign=top>Display when sold out:</td>
								<td align=left valign=top>
									<?=$data['display_when_sold_out'];?>
								</td>
							</tr>
							
							<?php if($vars['isInventoried']): ?>
							
								<?php if($vars['optionsInventoried'] && count($vars['inventoryData']) > 0):?>

 									<tr>
 		  								<td valign="top" colspan="2">
	 		  							
 		  									<table border="1" cellpadding="3" cellspacing="0" width="100%">
 		  										<tr>
 		  											<th>Option(s)</th>
 		  											<th nowrap>Min Qty</th>
 		  											<!--th>Max Qty</th-->
 		  											<th>Available</th>
 		  											<th>Sold</th>
 		  										</tr>
 		  										<?php foreach($vars['inventoryData'] as $i=>$flds):?>
 		  										
 		  										<tr>
 		  											<td width="70%">
 		  												<?php
 		  													$flds['name'] = str_replace("<br>","",$flds['name']);
 		  													$flds['name'] = str_replace('"',"&quot;",$flds['name']);
 		  													// this is for only one option in inventory. Was updated
 		  													// in inventory.inc line 88 - 10/24/07
 		  													if(empty($flds['oids']) && !empty($flds['oid'])){
 		  														$flds['oids'] = $flds['oid'];
 		  													}
 		  													if(empty($flds['odids']) && !empty($flds['odid'])){
 		  														$flds['odids'] = $flds['odid'];
 		  													}
 		  												?>
 		  												<input type="hidden" name="inventory[<?=$i;?>][pid]" value="<?=$flds['pid'];?>">
 		  												<input type="hidden" name="inventory[<?=$i;?>][oids]" value="<?=$flds['oids'];?>">
 		  												<input type="hidden" name="inventory[<?=$i;?>][odids]" value="<?=$flds['odids'];?>">
 		  												<input type="hidden" name="inventory[<?=$i;?>][name]" value="<?=$flds['name'];?>">
 		  												<?=$flds['name'];?>
 		  											</td>
 		  											<td>
 		  												<input class="rightalign" type="text" name="inventory[<?=$i;?>][minimum_quantity]" value="<?=$flds['minimum_quantity'];?>" size="5">
 		  											</td>
 		  											<!--td>
 		  												<input class="rightalign" type="text" name="inventory[<?=$i;?>][maximum_quantity]" value="<?=$flds['maximum_quantity'];?>" size="10">
 		  											</td-->
 		  											<td align="center">
 		  												<input class="rightalign" type="text" name="inventory[<?=$i;?>][quantity_available]" value="<?=$flds['quantity_available'];?>" size="5">
 		  											</td>
 		  											<td>
 		  												<input class="rightalign" type="text" name="inventory[<?=$i;?>][quantity_sold]" value="<?=$flds['quantity_sold'];?>" size="5">
 		  											</td>
 		  										</tr>
 		  										<?php endforeach;?>
 		  									</table>
 		  								</td>
 									</tr>
								
								<?php else:?>		  		
 									<tr>
 		  								<td align=right valign=top>Minimum Quantity:</td>
 										<td align=left valign=top>
 											<input type="hidden" name="inventory[0][pid]" value="<?=$vars['pid'];?>">
 											<input type="hidden" name="inventory[0][name]" value="<?=$data['name'];?>">
 		    								<input class=rightalign type=text name="inventory[0][minimum_quantity]" value="<?=$vars['inventoryData'][0]['minimum_quantity'];?>" size=8 ID="Text24">
 										</td>
 									</tr>
 									<!--tr>
 		  								<td align=right valign=top>Maximum Quantity Per Order:</td>
 										<td align=left valign=top>
 		    								<input class=rightalign type=text name="inventory[0][maximum_quantity]" value="<?=$vars['inventoryData'][0]['maximum_quantity'];?>" size=8 ID="Text25">
 										</td>
 									</tr-->
 									<tr>
 		  								<td align=right valign=top>Quantity Available:</td>
 										<td align=left valign=top>
 		    								<input class=rightalign type=text name="inventory[0][quantity_available]" value="<?=$vars['inventoryData'][0]['quantity_available'];?>" size=8 ID="Text26">
 										</td>
 									</tr>
 									<tr>
 		  								<td align=right valign=top>Quantity Sold:</td>
 										<td align=left valign=top>
 		    								<input class=rightalign type=text name="inventory[0][quantity_sold]" value="<?=$vars['inventoryData'][0]['quantity_sold'];?>" size=8 ID="Text27">
 										</td>
 									</tr>
 								<?php endif;?>
	 							
							<?php endif; ?>
							
							<tr><td colspan=2>&nbsp;</td></tr>
	  					</table>
					</td>
				</tr>
			<?php endif;?>

			<tr>
				<td width="10" valign="top"><img id="Img7" name="img.custom" src="images/plus.gif" style="cursor:hand;" onClick="showIt('custom');"></td>
		  		<td width="100%" align="left"><span style="cursor:hand;color=#800000;" onClick="showIt('custom');"><b>Custom Fields</b></span></td>
			</tr>

			<tr id="custom" style="display:none;">
				<td>&nbsp;</td>
				<td align="center" valign="top" style="border:1px solid #336699;">

					<table border=0 cellpadding=3 cellspacing=1 ID="Table8">
						<tr><td colspan=2>&nbsp;</td></tr>

						<?php foreach($data as $key=>$value):?>
							<?php 
								if(!isset($vars['customFields'][$key])){
									continue;
								}
								if(substr($key,0,7) == "detail_"){
									continue;	
								}
							?>
							<?php
								$strLen = 50;
								$match = array();
								preg_match("|varchar\((.*)\)|",$fldProperties[$key][1],$match);
								if(isset($match[1]) && $match[1] > 50 && strLen($value) > 50){
									$strLen = $match[1];
								}
								elseif($fldProperties[$key][1] == "text"){
									$strLen = 255;
								}
							?>
						
							<?php if(stristr($key,"id")){continue;}?>
							<?php $displayKey = ucwords(preg_replace("|\_|"," ",$key));?>
							<tr>
								<td align="right" valign="top"><?=$displayKey;?>: </td>
								<td valign="top">
									<?php if(substr($value,0,7) != "<select"):?>
									
										<?php if($strLen > 50):?>
											<textarea name="<?=$key;?>" rows="10" cols="50" wrap="virtual" ID="Textarea2"><?=$value;?></textarea>
										<?php else:?>
											<input type="text" name="<?=$key;?>" value="<?=$value;?>" size="<?=$strLen;?>" ID="Text28">
										<?php endif;?>
										
									<?php else:?>
									
										<?=$value;?>
									
									<?php endif;?>
								</td>
							</tr>
						<?php endforeach;?>	
						
						<tr><td colspan=2>&nbsp;</td></tr>
					</table>
					
				</td>
			</tr>
			
		</table>

		<p align="center">
			<?php if($add):?>
				<input class=buttons type="submit" name="insert" value="Add Product" onClick="return testEntries(this.form);">
				<?php if($_REQUEST['show_add'] == "true"):?>
					&nbsp;	<input type="checkbox" name="show_add" value="true" checked> Keep showing add screen
				<?php else:?>
					&nbsp;	<input type="checkbox" name="show_add" value="true"> Keep showing add screen
				<?php endif;?>	
			<?php else:?>
				<input class=buttons type="submit" name="update" value="Update Product" onClick="return testEntries(this.form);"> &nbsp; 
				<input class=buttons type="submit" name="delete" value="Delete Product" onclick="return confirm('Are you sure you want to delete this product?')">
			<?php endif;?>
		</p>

	</form>

	<script type="text/javascript">
		var selbox = "catid[]";
		var sIndex = document.forms['frmMain'].elements[selbox].selectedIndex;
		if(sIndex > 4){
			setTimeout("document.forms['frmMain'].elements[selbox].options[sIndex].selected=true;",10);
		}
	</script>


<?php else:?>

	<form method="get" action="products.php">
		<table border="0" cellpadding="3" cellspacing="0" align="center" width="95%" ID="Table2" style="border:1px solid #E5E5E5;">
			<tr bgcolor="#e2eDe2">
				<td>
					<b>Select Category:</b> <?=$vars['categoryList'];?>
				</td>
				<td align="right">
					<b>Enter SKU:</b> <input type="text" name="sku" size="10"> <input type="submit" name="go" value="Search">
				</td>
			</tr>
			<tr><td colspan="2" style="line-height:2px;">&nbsp;</td></tr>
			<tr>
				<td colspan="2" align="center">
					<?php if($vars['catid']):?>
						<h4><?=$vars['start'];?> - <?=$vars['end'];?> of <?=$vars['rsCount'];?> Items
					<?php else:?>
						<h4><?=$vars['start'];?> - <?=$vars['end'];?> of <?=$vars['rsCount'];?> Items
					<?php endif;?>
				</td>
			</tr>
			<tr>
				<td><b>Click on field name to sort results</b></td>
				<td align="right">&nbsp;
					<?php if($vars['previousNextLinks'] != ""):?>
						<?=$vars['previousNextLinks'];?>
					<?php endif;?>		
				</td>
			</tr>
			<tr><td colspan="2" style="line-height:2px;">&nbsp;</td></tr>
		</table>

		<table border="0" cellpadding="3" cellspacing="1" align="center" width="95%" ID="Table1">
			<tr>
				<th>&nbsp;</th>
				<th align=left><a href="products.php?list_products=true&sortby=category_link"><font color=white>Category</font></a></th>
				<th><a href="products.php?list_products=true&sortby=sku&catid=<?=$vars['catid'];?>"><font color=white>SKU</font></a></th>
				<th><a href="products.php?list_products=true&sortby=name&catid=<?=$vars['catid'];?>"><font color=white>Name</font></a></th>
				<th><a href="products.php?list_products=true&sortby=price&catid=<?=$vars['catid'];?>"><font color=white>Price</font></a></th>
				<th><a href="products.php?list_products=true&sortby=display_product&catid=<?=$vars['catid'];?>"><font color=white>Display</font></a></th>
				<th colspan=2>Manage</th>
			</tr>

			<?php $counter = 0;?>
			<?php foreach($data as $index=>$row):?>
				<?php
					$pid = $row['pid'];
					$itemNum = $row['sku'];
					$name = stripslashes($row['name']);
					$displayIt = $row['display_product'];
					$category = $row['catlinks'];
					$price = $_Common->calculateQuantityPrice($row['price']);
					$counter++;
				?>
				<tr bgcolor="<?=$color[$ck = ~$ck];?>">
					<td valign=top align=right width="20"><?=trim($counter);?></td>
					<td valign=top nowrap>&nbsp;<?=$category;?></td>
					<td valign=top><a href="products.php?edit=true&pid=<?=$pid;?>"><?=$itemNum;?></a></td>
					<td valign="top" width="40%" nowrap><?=$name;?></td>
					<td valign=top align="right" nowrap><?=$_Common->format_number($price);?></td>
					<td align=center valign="top"><?=$displayIt;?></td>
					<td align=center valign="middle" width="50"><a href="products.php?edit=true&pid=<?=$pid;?>"><img src="icons/txt.gif" border="0" alt="Edit"></a></td>
					<td align=center valign="middle" width="50"><a href="products.php?delete=true&pid=<?=$pid;?>&catid=<?=$vars['catid'];?>&mid=<?=$row['mid'];?>" onclick="return confirm('Are you sure you want to delete this product?')"><img src="icons/trash.gif" border="0" alt="Delete"></a></td>
				</tr>
			<?php endforeach;?>
			<tr><td colspan=7>&nbsp;</td></tr>
			<tr><td colspan=7><b>Total items returned = </b><?=$vars['rsCount'];?></td></tr>
		</table>
	</form>

<?php endif;?>

</div>
<p>&nbsp;</p>
</body>
</html>






