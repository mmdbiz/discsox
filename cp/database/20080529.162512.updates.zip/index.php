<?php
// initialize the program and read the config
include_once("include/initialize.inc");
$init = new Initialize();

// get the login class and see if required
$login = $_Registry->LoadClass('login');
$login->checkLogin();

// load the cart so we can display mini-cart
$cart = $_Registry->LoadClass('cart');

// get the store.index.html homepage
$vars = array();

$vars['metaDescription'] = $_CF['basics']['store_description'];
$vars['metaKeywords'] = $_CF['basics']['store_keywords'];

$indexPage = $_Template->Open("templates/store.index.html",$vars,true);
?>
<?=$indexPage;?>
